# Whisper Transcriber — Flutter Web Frontend

A basic Flutter web app with two working modes:

| Screen | Mirrors | What it does |
|---|---|---|
| **Live Microphone** | `test.py` | Records mic audio in-browser, uploads it, shows the transcript |
| **Prerecorded File** | `test2_prerecorded.py` | Lets you pick an existing audio file and transcribe it |

**System / Device Audio** (mirrors `test3_ondevice.py`) is shown as disabled —
browsers can't do OS-level loopback capture of a machine's own audio output,
so that mode only makes sense in a future native desktop build.

## Architecture

Whisper only runs in Python. This app just records/picks audio and uploads
it to a small FastAPI backend, which does the actual transcription and
returns text.

```
whisper_flutter/     <- this Flutter web app
whisper_backend/      <- separate Python project, run independently
  main.py             <- FastAPI server with CORS enabled
  requirements.txt
```

Run them as two separate processes — the Flutter app never launches Python
itself.

## Running the backend

```bash
cd whisper_backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

First run will download and load the Whisper model, so leave a minute for
"Model loaded. Ready for requests." to print before testing.

## Running the frontend

```bash
cd whisper_flutter
flutter config --enable-web
flutter create .          # adds the web/ folder, first time only
flutter pub get
flutter run -d chrome
```

`ApiService.baseUrl` in `lib/services/api_service.dart` is already set to
`http://localhost:8000` to match the backend above — change it if you run
the backend elsewhere.

## Notes

- Grant microphone permission when the browser prompts for it (works over
  `localhost` without HTTPS).
- CORS is wide open (`allow_origins=["*"]`) in `main.py` for local dev
  convenience — tighten that before putting the backend anywhere public.
