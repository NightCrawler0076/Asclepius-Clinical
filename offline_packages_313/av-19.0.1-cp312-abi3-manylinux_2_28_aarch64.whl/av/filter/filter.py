import cython
from cython.cimports import libav as lib
from cython.cimports.av.filter.link import alloc_filter_pads

_cinit_sentinel = cython.declare(object, object())


@cython.cfunc
def wrap_filter(ptr: cython.pointer[cython.const[lib.AVFilter]]) -> Filter:
    filter_: Filter = Filter(_cinit_sentinel)
    filter_.ptr = ptr
    return filter_


@cython.final
@cython.cclass
class Filter:
    def __cinit__(self, name):
        if name is _cinit_sentinel:
            return
        if not isinstance(name, str):
            raise TypeError("takes a filter name as a string")

        self.ptr = lib.avfilter_get_by_name(name)
        if not self.ptr:
            raise ValueError(f"no filter {name}")

    @property
    def name(self):
        return self.ptr.name

    @property
    def description(self):
        return self.ptr.description

    @property
    def flags(self):
        return self.ptr.flags

    @property
    def inputs(self):
        return alloc_filter_pads(self, self.ptr.inputs, True)

    @property
    def outputs(self):
        return alloc_filter_pads(self, self.ptr.outputs, False)


@cython.cfunc
def get_filter_names() -> set[str]:
    names: set[str] = set()
    ptr: cython.pointer[cython.const[lib.AVFilter]]
    opaque: cython.p_void = cython.NULL
    while True:
        ptr = lib.av_filter_iterate(cython.address(opaque))
        if ptr:
            names.add(ptr.name)
        else:
            break
    return names


filters_available = get_filter_names()
