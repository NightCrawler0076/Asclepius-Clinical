import cython
import cython.cimports.libav as lib
from cython.cimports.av.filter.graph import Graph
from cython.cimports.libc.stdint import uintptr_t

_cinit_sentinel = cython.declare(object, object())


@cython.final
@cython.cclass
class FilterLink:
    def __cinit__(self, sentinel):
        if sentinel is not _cinit_sentinel:
            raise RuntimeError("cannot instantiate FilterLink")

    @property
    def input(self):
        cctx: cython.pointer[lib.AVFilterContext] = self.ptr.src
        i: cython.Py_ssize_t
        for i in range(cctx.nb_outputs):
            if self.ptr == cctx.outputs[i]:
                break
        else:  # nobreak
            raise RuntimeError("could not find link in context")
        ctx = self.graph._context_by_ptr[cython.cast(cython.size_t, cctx)]
        return ctx.outputs[i]

    @property
    def output(self):
        cctx: cython.pointer[lib.AVFilterContext] = self.ptr.dst
        i: cython.Py_ssize_t
        for i in range(cctx.nb_inputs):
            if self.ptr == cctx.inputs[i]:
                break
        else:
            raise RuntimeError("could not find link in context")
        try:
            graph: Graph = self.graph
            ctx = graph._context_by_ptr[cython.cast(cython.size_t, cctx)]
        except KeyError:
            raise RuntimeError(
                "could not find context in graph", (cctx.name, cctx.filter.name)
            )
        return ctx.inputs[i]


@cython.cfunc
def wrap_filter_link(graph: Graph, ptr: cython.pointer[lib.AVFilterLink]) -> FilterLink:
    link: FilterLink = FilterLink(_cinit_sentinel)
    link.graph = graph
    link.ptr = ptr
    return link


@cython.cclass
class FilterPad:
    def __cinit__(self, sentinel):
        if sentinel is not _cinit_sentinel:
            raise RuntimeError("cannot construct FilterPad")

    def __repr__(self):
        _filter = self.filter.name
        _io = "inputs" if self.is_input else "outputs"

        return (
            f"<av.FilterPad {_filter}.{_io}[{self.index}]: {self.name} ({self.type})>"
        )

    def __eq__(self, other):
        """Two pads are equal when they denote the same pad.

        Pads are built on access rather than cached, so ``is`` compares the
        wrappers while this compares what they point at.
        """
        if not isinstance(other, FilterPad):
            return NotImplemented

        o: FilterPad = other
        if self.base_ptr != o.base_ptr or self.index != o.index:
            return False
        if self.is_input != o.is_input:
            return False
        if (self.context is None) != (o.context is None):
            return False
        return self.context is None or self.context.ptr == o.context.ptr

    def __hash__(self):
        return hash(
            (
                cython.cast(uintptr_t, self.base_ptr),
                self.index,
                self.is_input,
                0 if self.context is None else cython.cast(uintptr_t, self.context.ptr),
            )
        )

    @property
    def is_output(self):
        return not self.is_input

    @property
    def name(self):
        return lib.avfilter_pad_get_name(self.base_ptr, self.index)

    @property
    def type(self):
        media_type = lib.av_get_media_type_string(
            lib.avfilter_pad_get_type(self.base_ptr, self.index)
        )
        return "unknown" if media_type == cython.NULL else media_type


@cython.final
@cython.cclass
class FilterContextPad(FilterPad):
    def __repr__(self):
        _filter = self.filter.name
        _io = "inputs" if self.is_input else "outputs"
        context = self.context.name

        return f"<av.FilterContextPad {_filter}.{_io}[{self.index}] of {context}: {self.name} ({self.type})>"

    @property
    def link(self):
        if self._link:
            return self._link
        links: cython.pointer[cython.pointer[lib.AVFilterLink]] = (
            self.context.ptr.inputs if self.is_input else self.context.ptr.outputs
        )
        link: cython.pointer[lib.AVFilterLink] = links[self.index]
        if not link:
            return
        self._link = wrap_filter_link(self.context.graph, link)
        return self._link

    @property
    def linked(self):
        link: FilterLink = self.link
        if link:
            return link.input if self.is_input else link.output


@cython.cfunc
def alloc_filter_pads(
    filter: Filter,
    ptr: cython.pointer[cython.const[lib.AVFilterPad]],
    is_input: cython.bint,
    context: FilterContext | None = None,
) -> tuple[FilterPad, ...]:
    if not ptr:
        return ()

    pads: list[FilterPad] = []

    # We need to be careful and check our bounds if we know what they are,
    # since the arrays on a AVFilterContext are not NULL terminated.
    i: cython.int = 0
    count: cython.int
    if context is None:
        count = lib.avfilter_filter_pad_count(filter.ptr, not is_input)
    else:
        count = context.ptr.nb_inputs if is_input else context.ptr.nb_outputs

    pad: FilterPad
    while i < count:
        pad = (
            FilterPad(_cinit_sentinel)
            if context is None
            else FilterContextPad(_cinit_sentinel)
        )
        pads.append(pad)
        pad.filter = filter
        pad.context = context
        pad.is_input = is_input
        pad.base_ptr = ptr
        pad.index = i
        i += 1

    return tuple(pads)
